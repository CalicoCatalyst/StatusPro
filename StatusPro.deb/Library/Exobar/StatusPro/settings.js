var carrier = "calico"; // Name displayed by the apple icon (Try 3 characters or less)
var icon = "img/apple.png"; // Default: "img/apple.png" ; Icon to display in the status bar
var invertCarrierOnWhite = true; // Invert the carrier image on white backgrounds
var musicInfo = true; // Requires Extended Notch, display song name and artist directly under the physical notch.
var weatherFirst = false; //
var weatherBorder = false; // Add a border around the weather
var solidBlack = false;
var canOnlyBeOne = false; // Hide Cellular when wifi is connected

